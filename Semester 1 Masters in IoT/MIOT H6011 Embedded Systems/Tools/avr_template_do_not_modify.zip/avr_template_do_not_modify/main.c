/*
 * main.c
 *
 *  Created on: 12 Oct 2017
 *      Author: btoland
 */
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	//setup code goes here
	DDRB |= (1<<5);

	while(1)
	{
		//loop code goes here
		PORTB ^= (1<<5);
		_delay_ms(500);
	}
	return 0;
}

