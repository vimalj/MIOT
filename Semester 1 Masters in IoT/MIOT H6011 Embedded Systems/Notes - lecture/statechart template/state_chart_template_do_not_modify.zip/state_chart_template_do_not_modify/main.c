/*
 * main.c
 *
 *  Created on: 17 Sep 2015
 *      Author: benjie
 */

#include <avr/io.h>
#include <util/delay.h>

#include "avr/sleep.h"

#include "sc_timer/sc_timer_service.h"
#include "src-gen/State_chart.h"


static State_chart sc;


int main(void)
{
	DDRB |= (1<<5);

	sc_timer_setup();  //setup the statechart timers

	state_chart_init(&sc); //initialize statechart
	state_chart_enter(&sc); //enter the statechart

	while(1)
	{
		sc_timer_increment(10);  //increment statechart timer by 10ms
		state_chart_runCycle(&sc); //"run" the statechart
		_delay_ms(10);
	}

}

//Functions from State_chartRequired.h
void state_chartIface_setLight(const State_chart* handle, const sc_boolean lightOn) {
    if(lightOn)
        PORTB |= (1<<5);
    else
    	PORTB &= ~(1<<5);
}
