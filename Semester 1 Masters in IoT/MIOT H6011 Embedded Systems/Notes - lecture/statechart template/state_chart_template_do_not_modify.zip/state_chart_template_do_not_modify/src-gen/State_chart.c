
#include <stdlib.h>
#include <string.h>
#include "..\src\sc_types.h"
#include "State_chart.h"
#include "State_chartRequired.h"
/*! \file Implementation of the state machine 'state_chart'
*/

/* prototypes of all internal functions */
static sc_boolean state_chart_check_main_region_Off_tr0_tr0(const State_chart* handle);
static sc_boolean state_chart_check_main_region_On_tr0_tr0(const State_chart* handle);
static void state_chart_effect_main_region_Off_tr0(State_chart* handle);
static void state_chart_effect_main_region_On_tr0(State_chart* handle);
static void state_chart_enact_main_region_Off(State_chart* handle);
static void state_chart_enact_main_region_On(State_chart* handle);
static void state_chart_exact_main_region_Off(State_chart* handle);
static void state_chart_exact_main_region_On(State_chart* handle);
static void state_chart_enseq_main_region_Off_default(State_chart* handle);
static void state_chart_enseq_main_region_On_default(State_chart* handle);
static void state_chart_enseq_main_region_default(State_chart* handle);
static void state_chart_exseq_main_region_Off(State_chart* handle);
static void state_chart_exseq_main_region_On(State_chart* handle);
static void state_chart_exseq_main_region(State_chart* handle);
static void state_chart_react_main_region_Off(State_chart* handle);
static void state_chart_react_main_region_On(State_chart* handle);
static void state_chart_react_main_region__entry_Default(State_chart* handle);
static void state_chart_clearInEvents(State_chart* handle);
static void state_chart_clearOutEvents(State_chart* handle);


void state_chart_init(State_chart* handle)
{
		sc_integer i;
	
		for (i = 0; i < STATE_CHART_MAX_ORTHOGONAL_STATES; ++i)
		{
			handle->stateConfVector[i] = State_chart_last_state;
		}
		
		
		handle->stateConfVectorPosition = 0;
	
		state_chart_clearInEvents(handle);
		state_chart_clearOutEvents(handle);
	
}

void state_chart_enter(State_chart* handle)
{
	/* Default enter sequence for statechart state_chart */
	state_chart_enseq_main_region_default(handle);
}

void state_chart_exit(State_chart* handle)
{
	/* Default exit sequence for statechart state_chart */
	state_chart_exseq_main_region(handle);
}

sc_boolean state_chart_isActive(const State_chart* handle)
{
	sc_boolean result = bool_false;
	int i;
	
	for(i = 0; i < STATE_CHART_MAX_ORTHOGONAL_STATES; i++)
	{
		result = result || handle->stateConfVector[i] != State_chart_last_state;
	}
	
	return result;
}

/* 
 * Always returns 'false' since this state machine can never become final.
 */
sc_boolean state_chart_isFinal(const State_chart* handle)
{
   return bool_false;
}

static void state_chart_clearInEvents(State_chart* handle)
{
	handle->timeEvents.state_chart_main_region_Off_tev0_raised = bool_false;
	handle->timeEvents.state_chart_main_region_On_tev0_raised = bool_false;
}

static void state_chart_clearOutEvents(State_chart* handle)
{
}

void state_chart_runCycle(State_chart* handle)
{
	
	state_chart_clearOutEvents(handle);
	for (handle->stateConfVectorPosition = 0;
		handle->stateConfVectorPosition < STATE_CHART_MAX_ORTHOGONAL_STATES;
		handle->stateConfVectorPosition++)
		{
			
		switch (handle->stateConfVector[handle->stateConfVectorPosition])
		{
		case State_chart_main_region_Off:
		{
			state_chart_react_main_region_Off(handle);
			break;
		}
		case State_chart_main_region_On:
		{
			state_chart_react_main_region_On(handle);
			break;
		}
		default:
			break;
		}
	}
	
	state_chart_clearInEvents(handle);
}

void state_chart_raiseTimeEvent(const State_chart* handle, sc_eventid evid)
{
	if ( ((sc_intptr_t)evid) >= ((sc_intptr_t)&(handle->timeEvents))
		&&  ((sc_intptr_t)evid) < ((sc_intptr_t)&(handle->timeEvents)) + sizeof(State_chartTimeEvents))
		{
		*(sc_boolean*)evid = bool_true;
	}		
}

sc_boolean state_chart_isStateActive(const State_chart* handle, State_chartStates state)
{
	sc_boolean result = bool_false;
	switch (state)
	{
		case State_chart_main_region_Off :
			result = (sc_boolean) (handle->stateConfVector[SCVI_STATE_CHART_MAIN_REGION_OFF] == State_chart_main_region_Off
			);
			break;
		case State_chart_main_region_On :
			result = (sc_boolean) (handle->stateConfVector[SCVI_STATE_CHART_MAIN_REGION_ON] == State_chart_main_region_On
			);
			break;
		default:
			result = bool_false;
			break;
	}
	return result;
}




/* implementations of all internal functions */

static sc_boolean state_chart_check_main_region_Off_tr0_tr0(const State_chart* handle)
{
	return handle->timeEvents.state_chart_main_region_Off_tev0_raised;
}

static sc_boolean state_chart_check_main_region_On_tr0_tr0(const State_chart* handle)
{
	return handle->timeEvents.state_chart_main_region_On_tev0_raised;
}

static void state_chart_effect_main_region_Off_tr0(State_chart* handle)
{
	state_chart_exseq_main_region_Off(handle);
	state_chartIface_setLight(handle, bool_true);
	state_chart_enseq_main_region_On_default(handle);
}

static void state_chart_effect_main_region_On_tr0(State_chart* handle)
{
	state_chart_exseq_main_region_On(handle);
	state_chartIface_setLight(handle, bool_false);
	state_chart_enseq_main_region_Off_default(handle);
}

/* Entry action for state 'Off'. */
static void state_chart_enact_main_region_Off(State_chart* handle)
{
	/* Entry action for state 'Off'. */
	state_chart_setTimer(handle, (sc_eventid) &(handle->timeEvents.state_chart_main_region_Off_tev0_raised) , 500, bool_false);
}

/* Entry action for state 'On'. */
static void state_chart_enact_main_region_On(State_chart* handle)
{
	/* Entry action for state 'On'. */
	state_chart_setTimer(handle, (sc_eventid) &(handle->timeEvents.state_chart_main_region_On_tev0_raised) , 1 * 1000, bool_false);
}

/* Exit action for state 'Off'. */
static void state_chart_exact_main_region_Off(State_chart* handle)
{
	/* Exit action for state 'Off'. */
	state_chart_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.state_chart_main_region_Off_tev0_raised) );		
}

/* Exit action for state 'On'. */
static void state_chart_exact_main_region_On(State_chart* handle)
{
	/* Exit action for state 'On'. */
	state_chart_unsetTimer(handle, (sc_eventid) &(handle->timeEvents.state_chart_main_region_On_tev0_raised) );		
}

/* 'default' enter sequence for state Off */
static void state_chart_enseq_main_region_Off_default(State_chart* handle)
{
	/* 'default' enter sequence for state Off */
	state_chart_enact_main_region_Off(handle);
	handle->stateConfVector[0] = State_chart_main_region_Off;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for state On */
static void state_chart_enseq_main_region_On_default(State_chart* handle)
{
	/* 'default' enter sequence for state On */
	state_chart_enact_main_region_On(handle);
	handle->stateConfVector[0] = State_chart_main_region_On;
	handle->stateConfVectorPosition = 0;
}

/* 'default' enter sequence for region main region */
static void state_chart_enseq_main_region_default(State_chart* handle)
{
	/* 'default' enter sequence for region main region */
	state_chart_react_main_region__entry_Default(handle);
}

/* Default exit sequence for state Off */
static void state_chart_exseq_main_region_Off(State_chart* handle)
{
	/* Default exit sequence for state Off */
	handle->stateConfVector[0] = State_chart_last_state;
	handle->stateConfVectorPosition = 0;
	state_chart_exact_main_region_Off(handle);
}

/* Default exit sequence for state On */
static void state_chart_exseq_main_region_On(State_chart* handle)
{
	/* Default exit sequence for state On */
	handle->stateConfVector[0] = State_chart_last_state;
	handle->stateConfVectorPosition = 0;
	state_chart_exact_main_region_On(handle);
}

/* Default exit sequence for region main region */
static void state_chart_exseq_main_region(State_chart* handle)
{
	/* Default exit sequence for region main region */
	/* Handle exit of all possible states (of state_chart.main_region) at position 0... */
	switch(handle->stateConfVector[ 0 ])
	{
		case State_chart_main_region_Off :
		{
			state_chart_exseq_main_region_Off(handle);
			break;
		}
		case State_chart_main_region_On :
		{
			state_chart_exseq_main_region_On(handle);
			break;
		}
		default: break;
	}
}

/* The reactions of state Off. */
static void state_chart_react_main_region_Off(State_chart* handle)
{
	/* The reactions of state Off. */
	if (state_chart_check_main_region_Off_tr0_tr0(handle) == bool_true)
	{ 
		state_chart_effect_main_region_Off_tr0(handle);
	} 
}

/* The reactions of state On. */
static void state_chart_react_main_region_On(State_chart* handle)
{
	/* The reactions of state On. */
	if (state_chart_check_main_region_On_tr0_tr0(handle) == bool_true)
	{ 
		state_chart_effect_main_region_On_tr0(handle);
	} 
}

/* Default react sequence for initial entry  */
static void state_chart_react_main_region__entry_Default(State_chart* handle)
{
	/* Default react sequence for initial entry  */
	state_chart_enseq_main_region_Off_default(handle);
}


