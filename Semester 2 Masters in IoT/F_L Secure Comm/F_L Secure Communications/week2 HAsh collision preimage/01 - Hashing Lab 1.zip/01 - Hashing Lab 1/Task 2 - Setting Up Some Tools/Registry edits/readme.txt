Should work for Windows 8 and 10
There are two registry files 
- One to enable the hash context menu (right click on a file to see hash options) 
- The other to remove the change and set the system back to default setting.
