Here is a simple script to hash a string using your chosen cryptography algorithm.

Usage Examples:

Get-StringHash "My String to hash" "MD5"

Get-StringHash "My String to hash" "RIPEMD160"

Get-StringHash "My String to hash" "SHA1"

Get-StringHash "My String to hash" "SHA256"

Get-StringHash "My String to hash" "SHA384"

Get-StringHash "My String to hash" "SHA512"


For anyone trying to run powershell 
Copy the script file to c:

Need to Run powershell as admin

cd /
PS C:\> Set-ExecutionPolicy Unrestricted
PS C:\> . .\Get-StringHash.ps1
PS C:\> Get-StringHash "password" "MD5"
5f4dcc3b5aa765d61d8327deb882cf99